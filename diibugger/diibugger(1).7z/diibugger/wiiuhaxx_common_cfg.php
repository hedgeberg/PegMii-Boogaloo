<?php

$wiiuhaxxcfg_payloadfilepath = "code550.bin";
$wiiuhaxxcfg_loaderfilepath = "wiiuhaxx_loader.bin";

?>