./wiiuhaxx_locaterop.sh $1/v11464 0x0101c400 > wiiuhaxx_rop_sysver_532.php
./wiiuhaxx_locaterop.sh $1/v15702 0x0101c400 > wiiuhaxx_rop_sysver_550.php

